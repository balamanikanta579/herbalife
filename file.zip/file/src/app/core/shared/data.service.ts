/**
* home service
* Allow you to define code that's accessible and reusable throughout multiple components.
* @package dataService
* @author herbalife-apac-score-site,
*/

import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { httpService } from '../../core/shared/http.service'
import { HttpClient, HttpHeaders } from '@angular/common/http';


@Injectable({
  providedIn: 'root'
})
export class HomeService {
  
  
  constructor(private http: HttpClient,private HttpUrl:httpService) {  }

  getCountryDetails(): Observable<any> {
    return this.http.get<any>(this.HttpUrl.Country_Details,{observe:'response'});
  }

  sendWarehouseData(formData):Observable<any>{
    return this.http.post<any>(this.HttpUrl.Post_WareData,formData,{observe: 'response'});
  }
  

  getWareData(pageNumber):Observable<any>{
  let numRows=15;
  return this.http.get<any>(this.HttpUrl.Get_wareData+"/GetWarehouses?pageNumber="+pageNumber+"&noofRows="+numRows,{observe: 'response'});
  }

  getSearchedData(getSearch):Observable<any>{
    let numRows=15;
    let pageNumber=getSearch['currentPage'];
    let searchData=getSearch['search'];
    return this.http.get<any>(this.HttpUrl.search_wareData+"/Search?pageNumber="+pageNumber+"&noofRows="+numRows+"&searchData="+searchData,{observe: 'response'});
  }
  

  checkWareCode(wareData):Observable<any>{
    let checkCode= { "WHCode" : wareData };
    return this.http.post<any>(this.HttpUrl.check_wareData,checkCode,{observe: 'response'});
  }
  
  deleteWareData(value):Observable<any>{  
    let obj:any = { WHCode : value };
    return this.http.post<any>(this.HttpUrl.Delete_WareData,obj,{observe: 'response'});
  }

  editWareData(data):Observable<any>{
    return this.http.put<any>(this.HttpUrl.edit_waredata,data,{observe:'response'});
  }

  changeStatusData(status):Observable<any>{
    return this.http.put<any>(this.HttpUrl.status_wareData,status);
  }

  sendVendorData(formData):Observable<any>{
    return this.http.post<any>(this.HttpUrl.Post_VendorData,formData,{observe: 'response'});
  }

  getVendorsData(Data):Observable<any>{
    let sendDetails=Data;
    let numOfRecords:number=15;
    return this.http.get<any>(this.HttpUrl.Get_VendorData+"?pageNumber="+sendDetails['pageNumber']+"&noofRows="+numOfRecords+"+&searchData="+sendDetails['serachData'],{observe: 'response'}); 
  }


  checkVendorCode(obj):Observable<any>{
    return this.http.post<any>(this.HttpUrl.Check_VendorData,obj,{observe: 'response'});
  }

  editVendorData(data):Observable<any>{
    return this.http.put<any>(this.HttpUrl.Edit_VendorData,data,{observe:'response'});
  }

  deleteVendor(data):Observable<any>{
    return this.http.post<any>(this.HttpUrl.Delete_VendorData,data,{observe:'response'});
  }

  getVendorDetails():Observable<any>{
    return this.http.get<any>(this.HttpUrl.Get_VendorDetails,{observe:'response'});
  }

  sendVendorUserData(data):Observable<any>{
    return this.http.post<any>(this.HttpUrl.Send_VendorUserData,data,{observe: 'response'});
  }

  getVendorUsersData(Data):Observable<any>{
    let sendDetails=Data;
    let numOfRecords:number=15;
    return this.http.get<any>(this.HttpUrl.Get_VendorUserDetails+"?pageNumber="+sendDetails['pageNumber']+"&noofRows="+numOfRecords+"+&searchData="+sendDetails['serachData'],{observe: 'response'}); 
  }

  checkVendorUser(obj):Observable<any>{
    return this.http.post<any>(this.HttpUrl.Check_VendorUser,obj,{observe: 'response'});
  }

  statusVendor(data):Observable<any>{
    return this.http.put<any>(this.HttpUrl.status_Vendor,data);
  }

  updateVendorUserData(data):Observable<any>{
    return this.http.put<any>(this.HttpUrl.Update_VendorData,data,{observe:'response'});
  }
 

 
} 
