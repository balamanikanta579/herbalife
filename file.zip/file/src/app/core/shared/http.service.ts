/**
* home service
* Allow you to define code that's accessible and reusable throughout multiple components.
* @package httpService
* @author herbalife-apac-score-site,
*/

import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { environment } from '../../../environments/environment';


@Injectable({
  providedIn: 'root'
})
export class httpService { 

  public Country_Details = `${environment.serviceUrl}api/country`;  //get the country Details
  public Get_wareData = `${environment.serviceUrl}api/WareHouse`;  //get the waredata
  public check_wareData = `${environment.serviceUrl}api/WareHouse/GetWareHouse`;  //check the warehouse type
  public search_wareData = `${environment.serviceUrl}api/warehouse`;  //get the waredata
  public edit_waredata =  `${environment.serviceUrl}api/warehouse`;  //edit the waredata
  public status_wareData = `${environment.serviceUrl}api/warehouse`;  //status the waredata
  public Post_WareData = `${environment.serviceUrl}api/warehouse`;  //post the waredata
  public Delete_WareData = `${environment.serviceUrl}api/WareHouse/DeleteWareHouse`;  //delete the waredata
  public Post_VendorData = `${environment.serviceUrl}api/Vendor`;  //post the vendordata
  public Get_VendorData = `${environment.serviceUrl}api/Vendor/GetVendors`;  //get the vendordata
  public Check_VendorData = `${environment.serviceUrl}api/Vendor/GetVendor`;  //check the vendordata
  public Edit_VendorData = `${environment.serviceUrl}api/Vendor`;  //update the vendordata
  public Delete_VendorData = `${environment.serviceUrl}api/Vendor/DeleteVendor`;  //Delete the vendor
  public Get_VendorDetails= `${environment.serviceUrl}api/Vendor`;  //get  the vendor
  public status_Vendor = `${environment.serviceUrl}api/Vendor`;  //status the vendordata
  public Send_VendorUserData= `${environment.serviceUrl}api/VendorUser`;  //send  the vendoruser
  public Get_VendorUserDetails= `${environment.serviceUrl}api/VendorUser/GetVendorUsers`;  //get  the vendorusers
  public Check_VendorUser= `${environment.serviceUrl}api/VendorUser/GetVendorUser`;  // check  the vendorusers
  public Update_VendorData= `${environment.serviceUrl}api/VendorUser`;  // update  the vendorusers
  
  

  
 
} 
