/**
* http interceptor
* Interceptors provide a mechanism to intercept and/or mutate outgoing requests or incoming responses, features like caching and logging.
* @package InterceptorsService
* @subpackage interceptorservice
* @author herbalife-apac-score-site,
*/

import { Injectable } from '@angular/core';
import {HttpRequest,HttpHandler,HttpEvent,HttpInterceptor,HttpErrorResponse} from '@angular/common/http';
import { Observable, throwError } from 'rxjs';
import { retry, catchError } from 'rxjs/operators';
import { ToastrService } from 'ngx-toastr';


@Injectable()
export class InterceptorsService implements HttpInterceptor {
  userInfo: string;
  profileData: any;
  constructor(private toastar:ToastrService){}
  intercept(req: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>> {
    return next.handle(req)
    .pipe(retry(1),
      catchError((error: HttpErrorResponse) => {
        let errorMessage = '';
        if (error.error instanceof ErrorEvent) {
          // client-side error
          errorMessage = `Something went wrong. Try again later`;
        } else {
          // server-side error
          errorMessage = `Something went wrong. Try again later`;
        }
        this.toastar.error(errorMessage);  
        return throwError(errorMessage);
      })
    );
  }
}


