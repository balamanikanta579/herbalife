import { Component, OnInit } from '@angular/core';
import { ToastrService } from 'ngx-toastr';
import {HomeService} from '../../../core/shared/data.service';
import {FormGroup,FormBuilder, Validators,FormControl,AbstractControl} from '@angular/forms';
import { debounceTime, delay,distinctUntilChanged } from 'rxjs/operators'

declare var $ :any;


@Component({
  selector: 'app-warehouse',
  templateUrl: './warehouse.component.html',
  styleUrls: ['./warehouse.component.css']
})
export class WarehouseComponent implements OnInit {

  warehouse:FormGroup;
  mymodel:any;
  countryDetails:Array<any>=[];
  active:boolean=false;
  wareDetails:Array<any>=[];
  viewData:any;
  checkboxFlag:boolean;
  spins:boolean=false;
  p: number = 1;
  total:number=15;
  currentPage:number;
  filterData:any;
  num:number=1;
  numRows:number=15;
  data:any;
  loading = true;
  checkLength:string = '';
  sendSearchData:any;
  whCheck:boolean=false;
  isSearching:number = 0;
  wareHouse:any;
  placedata:any;
  anotherdata:any;
  checkSpin:boolean=false;
  upadateFlag:boolean;
  

  constructor(private toastr:ToastrService,private home:HomeService) {    
  }


  searchData(data){
    this.checkLength=data;
    if(data.length > 1) {
       if(this.currentPage > 1 && this.isSearching <= 0) {
         let firstPage=1;
          this.sendSearchData={currentPage:firstPage,search:this.checkLength};
         } else {
          this.sendSearchData={currentPage:this.currentPage,search:this.checkLength};
         }
         this.home.getSearchedData(this.sendSearchData).subscribe(res=>{
         var getSearchData=res['body'];
         if(res.status == 200) {
            this.wareDetails= getSearchData['result'];
            this.total=getSearchData['noOfRecords'];   
            if(this.isSearching > 0)
              this.currentPage = this.currentPage;
            else         
              this.currentPage = 1;
          }
          else if(res.status == 204) {
            this.wareDetails = [];
          }});
        } else {
        if(this.isSearching > 0)
          this.currentPage = 1;
        this.getWareData(this.currentPage);
     }
  }

  getCountryDetails(){
    this.home.getCountryDetails().subscribe(res=>{
      this.countryDetails=res['body'];
    });
  }

  getWareData(num){
        this.currentPage=num;
          if(this.checkLength.length > 1){
            if(this.isSearching >= 0)
              ++this.isSearching;
              console.log(this.currentPage);
            this.searchData(this.checkLength);
            } else if(this.checkLength.length <= 1) {
              if(this.isSearching > 0)
                --this.isSearching;
            this.home.getWareData(this.currentPage).subscribe(res=>{
            this.loading=false;
            var getData=res['body'];
            if(res.status == 200){
            this.wareDetails= getData['result'];
            this.total= getData['noOfRecords'];
            }
            });
        }
  } 

  resetform(){
    this.warehouse.reset();
    this.spins=false;
    this.whCheck=false;
    this.checkSpin=false;
    $("#exampleModalCenter").modal("hide");
  }

  status(statusData){
    this.viewData=statusData;
    this.checkboxFlag=this.viewData.Active;
  }

  addData(){
    this.upadateFlag=false;
  }

  sendData(formData){
    this.spins=true;
    let wareData = {};
    wareData['CountryCode']=formData.CountryCode;
    wareData['WHCode']=formData.WHCode;
    wareData['WHType']=formData.WHType;
    wareData['City']=formData.City;
    wareData['Active']=false;
    this.home.sendWarehouseData(wareData).subscribe(res=>{
        this.spins=false;
        if(res.status==201) {
        this.warehouse.reset();
        this.getWareData(this.num);
        $("#exampleModalCenter").modal("hide");
        this.toastr.success("Warehouse saved successfully");
        }},(error) => {
          this.spins=false;
          if(error.status==500) {
            this.toastr.error("something went wrong.Try again later");
      }});
    }

  ngOnInit() {
    this.warehouse = new FormGroup({
        'CountryCode': new FormControl(null, [Validators.required]),
        'WHCode': new FormControl(null, [Validators.required, Validators.maxLength(10)]),
        'WHType': new FormControl(null, [Validators.required, Validators.maxLength(20)]),
        'City': new FormControl(null, [Validators.required, Validators.maxLength(100)])
    });
    this.getCountryDetails();
    this.getWareData(this.num);
    this.formReset();
  }

  formReset(){
    $("#exampleModalCenter .modal-dialog").click(function(event){
      event.stopPropagation();
    });
    this.whCheck=false;
    this.checkSpin=false;
    this.warehouse.reset();
  }

  get CountryCode() { return this.warehouse.get('CountryCode'); }
  get WHCode() { return this.warehouse.get('WHCode'); }
  get WHType() { return this.warehouse.get('WHType'); }
  get City() { return this.warehouse.get('City'); }


  whCodeCheck(value){
    if(value.length >= 1){
      this.checkSpin=true;
      this.home.checkWareCode(value).subscribe(res => {
        this.checkSpin=false;
       if(res.status == 200) {
          this.whCheck=false;
          }},(error) => { 
          if(error.status==409) {
             this.checkSpin=false;
             this.whCheck=true; }});
       } else { 
       this.whCheck=false;
  }}

   editData(updateData){
    $("#warehouseUpdate").modal("hide");
    $("#exampleModalCenter").modal("show");
    this.warehouse.patchValue({
      'CountryCode':updateData.CountryCode,
      'WHCode':updateData.WHCode,
      'WHType':updateData.WHType,
      'City':updateData.City
    });
    this.upadateFlag=true;
   }

    updateData(formdata){
      this.spins=true;
      this.home.editWareData(formdata).subscribe(res=>{
        this.spins=false;
        if(res.status==200) {
        this.warehouse.reset();
        this.getWareData(this.currentPage);
        $("#exampleModalCenter").modal("hide");
        this.toastr.success("Warehouse data updated successfully");
        }},(error) => {
          this.spins=false;
          this.getWareData(this.currentPage);
          if(error.status==500) {
          this.toastr.error("something went wrong. please try again");
        }});
    }

  
  changeStatus($event){
    let activeUser= {
      "WHCode":this.viewData.WHCode,
      "Active":$event.target.checked
    }
    this.home.changeStatusData(activeUser).subscribe(res=>{
       if(res.Active == true){
        this.toastr.success("Warehouse code "+res.WHCode+ " activated successfully");
        this.getWareData(this.currentPage);
       } else if(res.Active == false) {
        this.toastr.success("Warehouse code "+res.WHCode+ " deactivated successfully");
        this.getWareData(this.currentPage);
       }});
   }

   delete(value){
    if(confirm("Are you sure you want to delete this warehouse ?")){
      this.home.deleteWareData(value).subscribe(res=>{
         if(res.status == 200) {
          this.getWareData(this.currentPage);
          $("#warehouseUpdate").modal("hide");
          this.toastr.success("Warehouse successfully deleted");
          }},(error) => {
           if(error.status == 409){
          this.getWareData(this.currentPage);
          $("#warehouseUpdate").modal("hide");
          this.toastr.error("Warehouse cannot be deleted, as there exist data mapped to this warehouse");
         }
       });
     } 
  }

  

}
