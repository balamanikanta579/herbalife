import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import {WarehouseComponent} from './warehouse/warehouse.component';
import { VendorComponent } from './vendor/vendor.component';
import { VendorsusersComponent } from './vendorsusers/vendorsusers.component';


const routes: Routes = [
  { 
    path:'', 
    component: VendorsusersComponent 
  },
  { 
    path:'warehouse', 
    component: WarehouseComponent 
  },
  { 
    path:'vendor', 
    component: VendorComponent 
  },
  { 
    path:'vendoruser', 
    component: VendorsusersComponent
  }
];


@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class ReportadminRoutingModule { }
