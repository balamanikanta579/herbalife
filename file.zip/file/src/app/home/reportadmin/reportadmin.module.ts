import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ReportadminRoutingModule } from './reportadmin-routing.module';
import { WarehouseComponent } from './warehouse/warehouse.component';
import {FormsModule,ReactiveFormsModule} from '@angular/forms';
import {HttpClientModule} from '@angular/common/http';
import {NgxPaginationModule} from 'ngx-pagination';
import { VendorComponent } from './vendor/vendor.component';
import { VendorsusersComponent } from './vendorsusers/vendorsusers.component';



@NgModule({
  declarations: [WarehouseComponent, VendorComponent, VendorsusersComponent],
  imports: [
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    HttpClientModule,
    ReportadminRoutingModule,
    NgxPaginationModule
  ]
})
export class ReportadminModule { }
