import { ComponentFixture, TestBed } from '@angular/core/testing';

import { VendorsusersComponent } from './vendorsusers.component';

describe('VendorsusersComponent', () => {
  let component: VendorsusersComponent;
  let fixture: ComponentFixture<VendorsusersComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ VendorsusersComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(VendorsusersComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
