import { Component, OnInit } from '@angular/core';
import { ToastrService } from 'ngx-toastr';
import {HomeService} from '../../../core/shared/data.service';
import {FormGroup,FormBuilder, Validators,FormControl,AbstractControl} from '@angular/forms';
import { debounceTime, delay,distinctUntilChanged } from 'rxjs/operators'
import { IfStmt, IvyParser } from '@angular/compiler';

declare var $ :any;


@Component({
  selector: 'app-vendorsusers',
  templateUrl: './vendorsusers.component.html',
  styleUrls: ['./vendorsusers.component.css']
})
export class VendorsusersComponent implements OnInit {

  vendoruser:FormGroup;
  VendorDetails:Array<any>=[];
  currentPage:number=1;
  numRows:number=15;
  searchValue:string='';
  loading:boolean=false;
  searchFlag:boolean;
  vendorDetails:Array<any>=[];
  total:number;
  spins:boolean;
  uservalue:string;
  vendorUserValue:string;
  vendorId:number;
  checkSpin:boolean;
  vmCheck:boolean;
  checkValueExist:boolean;
  vendorDetailsfilter:Array<any>=[];
  vendorfilterFlag:boolean;
  vendorName:any;
  numberFlag:boolean;
  filterFlag:boolean;
  VendorUserDetails:Array<any>=[];
  vendorValue:string;
  viewData:Array<any>=[];
  upadateFlag: boolean;
  vendorUserId:number;
  

  

  constructor(private toastr:ToastrService,private home:HomeService) {  
   
  }

  getVendorDetails(){
    this.home.getVendorDetails().subscribe(res=>{
      this.VendorUserDetails=res['body'];
    });
  }

  


  ngOnInit(): void {
    this.vendoruser = new FormGroup({
      'username': new FormControl(null,[Validators.required]),
      'email': new FormControl(null, [Validators.required, Validators.email, Validators.maxLength(50)]),
      'vendorname': new FormControl(null,Validators.required),
  });
  this.getVendorDetails();
  this.getVendorUserData(this.currentPage);
  this.resetform();
  }


  searchData(event){
    var searchValue:string=event.target.value;
    if(searchValue.length > 1){
    this.searchValue=searchValue;
    this.currentPage=1;
    this.searchFlag=true;
    this.getVendorUserData(this.currentPage);
    } else if( this.searchFlag && searchValue.length <= 1) {
    this.searchValue='';
    this.currentPage=1;
    this.searchFlag=false;
    this.getVendorUserData(this.currentPage);
   }
  }

  getVendorUserData(currentPageNumber){
    this.loading=true;
    this.currentPage=currentPageNumber;
    let paginationSearch={pageNumber:currentPageNumber,serachData:this.searchValue}
    this.home.getVendorUsersData(paginationSearch).subscribe((res:Response)=>{
    this.loading=false;
    var getresData=res['body'];
    if(res.status == 200){
       this.vendorDetails=getresData['result'];
       this.total=getresData['noOfRecords'];
       } else if(res.status == 204 || res.status == 500) {
         this.loading=false;
       this.vendorDetails= [];
    }});
 }

  sendData(formData){
    this.spins=true;
    let vendor = {};
    vendor['DisplayName']=formData.username;
    vendor['Email']=formData.email;
    vendor['VendorId']=this.vendorId;
    vendor['Active']=false;
    this.home.sendVendorUserData(vendor).subscribe(res=>{
        this.spins=false;
        if(res.status==201) {
        this.vendoruser.reset();
        $("#exampleModalCenter").modal("hide");
        this.getVendorUserData(this.currentPage);
        this.toastr.success("user data added successfully");
        }},(error) => {
            if(error.status==500) {
            this.toastr.error("something went wrong. Try again later");
      }});
    }


    vendorFilter(value){
            var vendorUser=value;
            this.numberFlag=false;
            this.checkValueExist=false;
            this.filterFlag = true;
            if(value.length >= 1) {
            this.vendorName=vendorUser;
            this.vendorDetailsfilter=this.VendorUserDetails;
            this.vendorDetailsfilter=this.vendorDetailsfilter.filter(function(thisperson){
            return thisperson.VendorName.toLowerCase().includes(vendorUser.toLowerCase());
            });
            if(this.vendorDetailsfilter.length == 0) {
              this.vendorfilterFlag=true;
            } else {
              this.vendorfilterFlag=false;
            } } else {
            this.vendorfilterFlag=false;
            this.vendorDetailsfilter=[];
            }
    }

   vendorCheck(value){
      this.checkSpin=true;
      let obj={Email:this.vendorUserValue,VendorId:value};
      this.home.checkVendorUser(obj).subscribe(res => {
      this.checkSpin=false;
      if(res.status == 200) {
        this.checkValueExist=false;
        }},(error) => { 
          this.checkSpin=false;
          if(error.status==409) {
          this.vendorValue=this.vendoruser.controls['vendorname'].value;
          this.checkValueExist=true;
          this.checkSpin=false;
        }});
   } 

   
  addData(){
    this.upadateFlag=false;
  }
   

  sendvendorId(value){
     this.vendorId=value.VendorId;
     this.vendoruser.controls['vendorname'].setValue(value.VendorName);
     this.vendorDetailsfilter=[];
     this.checkValueExist=false;
     this.filterFlag=false;
     this.numberFlag=true;
     if (this.vendoruser.controls['email'].value !==null && this.vendoruser.controls['email'].value !== ""){
      this.vendorCheck(this.vendorId);
     }
  } 

  sendEmail(value){
    this.checkValueExist=false;
    this.filterFlag=false;
    if(value.length >= 1){
    this.vendorUserValue=value;
    if(this.numberFlag){
      if (this.vendoruser.controls['vendorname'].value !==null && this.vendoruser.controls['vendorname'].value !== ""){
       this.vendorCheck(this.vendorId);
      } 
     }
   }
  }

  get username() { return this.vendoruser.get('username'); }
  get email() { return this.vendoruser.get('email'); }
  get vendorname() { return this.vendoruser.get('vendorname'); }

  resetform(){
    this.vendoruser.reset();
    this.spins=false;
    this.checkValueExist=false;
    this.vendorfilterFlag=false;
    this.vendorDetailsfilter=[];
    $("#exampleModalCenter").modal("hide");
  }

  status(data){
    this.viewData=data;
    this.vendorUserId=data.VendorUserId;
  }

  editData(updateData){
    $("#warehouseUpdate").modal("hide");
    $("#exampleModalCenter").modal("show");
    this.vendoruser.setValue({
      'username':updateData.DisplayName,
      'email':updateData.Email,
      'vendorname':updateData.VendorName
    });
    this.upadateFlag=true;
  }

  updateData(formdata){
    this.spins=true;
    let editVendor={};
    editVendor['DisplayName']=formdata.username;
    editVendor['Email']=formdata.email;
    editVendor['VendorUserId']=this.vendorUserId;
    this.home.updateVendorUserData(editVendor).subscribe(res=>{
      this.spins=false;
      if(res.status==200) {
      this.vendoruser.reset();
      this.getVendorUserData(this.currentPage);
      $("#exampleModalCenter").modal("hide");
      this.toastr.success("Vendor user data updated successfully");
      }},(error) => {
        this.spins=false;
        this.getVendorUserData(this.currentPage);
        if(error.status==500) {
        this.toastr.error("something went wrong. please try again");
      }
    });
  }



 
}
