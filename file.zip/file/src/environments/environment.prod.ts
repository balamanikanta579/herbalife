export const environment = {
  production: true,
  serviceUrl: 'http://3.217.154.128:7070/'
  //serviceUrl: 'https://localhost:44388/'
};
